/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dto;

/**
 *
 * @author blueb
 */
public class ProductDTO {
        private String productID;
        private String productName;
        private String desc;
        private String cateID;
        private float price;
        private int quantity;
        private boolean statusID;
        private String imge;

    public ProductDTO(String productID, String productName, String desc, String cateID, float price, int quantity, boolean statusID, String imge) {
        this.productID = productID;
        this.productName = productName;
        this.desc = desc;
        this.cateID = cateID;
        this.price = price;
        this.quantity = quantity;
        this.statusID = statusID;
        this.imge = imge;
    }

    public ProductDTO() {
    }

    public String getProductID() {
        return productID;
    }

    public void setProductID(String productID) {
        this.productID = productID;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getCateID() {
        return cateID;
    }

    public void setCateID(String cateID) {
        this.cateID = cateID;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public boolean isStatusID() {
        return statusID;
    }

    public void setStatusID(boolean statusID) {
        this.statusID = statusID;
    }

    public String getImge() {
        return imge;
    }

    public void setImge(String imge) {
        this.imge = imge;
    }
        
        
}
