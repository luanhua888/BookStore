/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dto;

/**
 *
 * @author blueb
 */
public class ProductError {

    private String productIDError;
    private String productNameError;
    private String descError;
    private String cateIDError;
    private String priceError;
    private String quantityError;
    private String imgeError;

    public ProductError(String productIDError, String productNameError, String descError, String cateIDError, String priceError, String quantityError, String imgeError) {
        this.productIDError = productIDError;
        this.productNameError = productNameError;
        this.descError = descError;
        this.cateIDError = cateIDError;
        this.priceError = priceError;
        this.quantityError = quantityError;
        this.imgeError = imgeError;
    }

    public ProductError() {
        this.productIDError = "";
        this.productNameError = "";
        this.descError = "";
        this.cateIDError = "";
        this.priceError = "";
        this.quantityError = "";
        this.imgeError = "";
    }

    public String getProductIDError() {
        return productIDError;
    }

    public void setProductIDError(String productIDError) {
        this.productIDError = productIDError;
    }

    public String getProductNameError() {
        return productNameError;
    }

    public void setProductNameError(String productNameError) {
        this.productNameError = productNameError;
    }

    public String getDescError() {
        return descError;
    }

    public void setDescError(String descError) {
        this.descError = descError;
    }

    public String getCateIDError() {
        return cateIDError;
    }

    public void setCateIDError(String cateIDError) {
        this.cateIDError = cateIDError;
    }

    public String getPriceError() {
        return priceError;
    }

    public void setPriceError(String priceError) {
        this.priceError = priceError;
    }

    public String getQuantityError() {
        return quantityError;
    }

    public void setQuantityError(String quantityError) {
        this.quantityError = quantityError;
    }

    

    public String getImgeError() {
        return imgeError;
    }

    public void setImgeError(String imgeError) {
        this.imgeError = imgeError;
    }
    
}
