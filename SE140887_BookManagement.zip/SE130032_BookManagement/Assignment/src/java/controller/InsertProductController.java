/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import dao.ProductDAO;
import dto.ProductDTO;
import dto.ProductError;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author blueb
 */
@WebServlet(name = "InsertProductController", urlPatterns = {"/InsertProductController"})
public class InsertProductController extends HttpServlet {

    private static final String ERROR = "insertProduct.jsp";
    private static final String SUCCESS = "admin.jsp";

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String url = ERROR;
        try {
            String productID = request.getParameter("proID");
            String productName = request.getParameter("proName");
            String description = request.getParameter("desc");
            float price = Float.parseFloat(request.getParameter("price"));
            int quantity = Integer.parseInt(request.getParameter("quantity"));
            String categoryID = request.getParameter("cateID");
            String imgURL = request.getParameter("imgLink");
            ProductError error = new ProductError();
            ProductDAO dao = new ProductDAO();
            boolean check = true;
            if (productID.length() < 3 || productID.length() > 10 || !productID.matches("B-\\d{2}")) {
                error.setProductIDError("Invalid ID ! Follow format B-xx and length not higher than 10");
                check = false;
            }
            
            if (productName.length() < 3 || productName.length() > 50) {
                error.setProductIDError("Invalid Name length not higher than 10");
                check = false;
            }
             if (description.length() < 3 || description.length() > 200) {
                error.setProductIDError("Invalid Description and length not higher than 200");
                check = false;
            }
            if (price < 0) {
                error.setPriceError("Book price must > 0");
                check = false;
            }

            if (quantity < 0) {
                error.setQuantityError("Quantity must > 0");
                check = false;
            }

            String cateCheck = dao.getCateID(categoryID);
            if (!cateCheck.equalsIgnoreCase(categoryID)) {
                error.setCateIDError("Not match in database");
                check = false;
            }
            
            if (check) {
                boolean checkDup = dao.checkDup(productID);
                ProductDTO dto = new ProductDTO(productID, productName, description, categoryID, price, quantity, true, imgURL);
                if (checkDup) {
                    error.setProductIDError(productID + " has already!");
                    request.setAttribute("Product_E", error);
                } else {
                    boolean ins = dao.InsertBook(dto);
                    if (ins) {
                        url = SUCCESS;
                    }
                }
            } else {
                request.setAttribute("Product_E", error);
            }
        } catch (Exception e) {
        } finally {
            request.getRequestDispatcher(url).forward(request, response);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
