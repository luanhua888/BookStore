/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import dao.UserDAO;
import dto.UserDTO;
import dto.UserError;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author blueb
 */
@WebServlet(name = "RegisterController", urlPatterns = {"/RegisterController"})
public class RegisterController extends HttpServlet {
    LocalDateTime currentDateTime = LocalDateTime.now();
    static DateTimeFormatter formatter = DateTimeFormatter.ISO_DATE_TIME;
    private static final String ERROR = "register.jsp";
    private static final String SUCCESS = "login.html";

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String url = ERROR;
        try {
            String userID = request.getParameter("userID");
            String fullName = request.getParameter("fullName");
            String password = request.getParameter("password");
            String confirm = request.getParameter("confirm");
            String phone = request.getParameter("phone");
            String address = request.getParameter("address");
            String date =  currentDateTime.format(formatter);
            boolean check = true;
            UserError error = new UserError();

            if (userID.length() > 10 || userID.length() < 3) {
                error.setUserIDError("Please input just in [3,10]");
                check = false;
            }

            if (fullName.length() > 50 || fullName.length() < 3) {
                error.setFullNameError("Please input just in [3,50]");
                check = false;
            }
            if (!confirm.equals(password)) {
                error.setConfirmError("Dont match!");
                check = false;
            }
            if (phone.length() > 15 || phone.length() < 9|| !phone.matches("\\b\\d+\\b") ) {
                error.setPhoneError("Please input just in 9 to 15 digits");
                check = false;
            }
            if (address.length() > 200) {
                error.setAddressError("Invalid address");
                check = false;
            }
            if (check) {
                UserDAO daO = new UserDAO();
                UserDTO user = new UserDTO(userID, fullName, password, phone, address, "US", true, date);
                boolean checkID = daO.checkDuplicateID(userID);
                if (checkID) {
                    error.setUserIDError(userID + " has already!");
                    request.setAttribute("USER_ERR", error);
                } else {
                    boolean checkIns = daO.createUser(user);
                    if (checkIns) {
                        url = SUCCESS;
                    } else {
                        error.setMessError("Can't not register");
                        request.setAttribute("USER_ERR", error);
                    }
                }
            } else {
                request.setAttribute("USER_ERR", error);
            }
        } catch (Exception e) {
            log("Error At RegisterController:" + e.toString());
        } finally {
            request.getRequestDispatcher(url).forward(request, response);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
