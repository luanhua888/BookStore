/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import dao.ProductDAO;
import dto.DetailDTO;
import dto.ProductDTO;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.tomcat.util.buf.B2CConverter;

/**
 *
 * @author blueb
 */
public class AddToCartController extends HttpServlet {
    
    private static final String ERROR = "error.jsp";
    private static final String SUCCESS = "product.jsp";

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String url = ERROR;
        String id = request.getParameter("productID");
        ProductDAO daO = new ProductDAO();
        int quantity = 1;
        DetailDTO detail = new DetailDTO();
        ArrayList<DetailDTO> deList = null;
        boolean flag = true;
        try {
            ProductDTO proDTO = daO.getListBookByID(id);
            detail = new DetailDTO(0, proDTO.getPrice(), quantity, 0, proDTO);
            HttpSession sess = request.getSession();
            deList = (ArrayList<DetailDTO>) sess.getAttribute("CART");
            if (deList != null) {
                for (int i = 0; i < deList.size(); i++) {
                    if (deList.get(i).getPro().getProductID() == detail.getPro().getProductID()) {
                        int curQuantity = daO.getQuantityOfBook(id);
                        if (deList.get(i).getQuantity() + 1 <= curQuantity) {
                            detail.setQuantity(deList.get(i).getQuantity() + 1);
                            deList.set(i, detail);
                        } else {
                            request.setAttribute("OUT", "SORRY Out Of Quantity");
                        }
                        flag = false;
                    }
                }
            } else if (deList == null) {
                deList = new ArrayList<>();
            }
            if (flag) {
                deList.add(detail);
            }
             sess.setAttribute("CART", deList);
            url =SUCCESS;
            request.setAttribute("MESSAGE", "This book " + detail.getPro().getProductName() + " was added successfully");
        } catch (Exception e) {
        } finally {
            request.getRequestDispatcher(url).forward(request, response);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
