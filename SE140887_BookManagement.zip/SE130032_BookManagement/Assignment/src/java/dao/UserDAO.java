/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import dto.UserDTO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import ultis.DB_Ultis;
import dto.UserDTO;

/**
 *
 * @author blueb
 */
public class UserDAO {

    public Connection conn = null;
    public PreparedStatement ps = null;
    public ResultSet rs = null;

    private void closeConnection() throws SQLException {
        if (rs != null) {
            rs.close();
        }
        if (ps != null) {
            ps.close();
        }
        if (conn != null) {
            conn.close();
        }
    }

    public UserDTO checkLogin(String userID, String password) throws SQLException {
        UserDTO user = null;
        try {
            conn = DB_Ultis.getConnection();
            if (conn != null) {
                String sql = "SELECT userID,fullName,phone,address,roleID,statusID,createDate "
                        + "FROM tblUser "
                        + "WHERE userID =? AND password =?";
                ps = conn.prepareStatement(sql);
                ps.setString(1, userID);
                ps.setString(2, password);
                rs = ps.executeQuery();
                while (rs.next()) {
                    String name = rs.getString("fullName");
                    String phone = rs.getString("phone");
                    String address = rs.getString("address");
                    String roleID = rs.getString("roleID");
                    boolean status = rs.getBoolean("statusID");
                    String date = rs.getString("createDate");
                    user = new UserDTO(userID, name, "", phone, address, roleID, status, date);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            closeConnection();
        }
        return user;
    }

    public boolean createUser(UserDTO user) throws SQLException {
        boolean check = false;

        try {
            conn = DB_Ultis.getConnection();
            if (conn != null) {
                String sql = "INSERT INTO tblUser(userID,fullName,password,phone,address,roleID,statusID,createDate) "
                        + "VALUES(?,?,?,?,?,?,?,?)";
                ps = conn.prepareStatement(sql);
                ps.setString(1, user.getUserID());
                ps.setString(2, user.getFullName());
                ps.setString(3, user.getPassword());
                ps.setString(4, user.getPhone());
                ps.setString(5, user.getAddress());
                ps.setString(6, user.getRoleID());
                ps.setBoolean(7, user.isStatusID());
                ps.setString(8, user.getCreateDate());
                check = ps.executeUpdate() > 0;
            }
        } catch (Exception e) {
        } finally {
            if (ps != null) {
                ps.close();
            }
            if (conn != null) {
                conn.close();
            }
        }
        return check;
    }

    public boolean checkDuplicateID(String userID) throws SQLException {
        boolean check = false;
        try {
            conn = DB_Ultis.getConnection();
            if (conn != null) {
                String sql = "SELECT userID FROM tblUser WHERE userID = ?";
                ps = conn.prepareStatement(sql);
                ps.setString(1, userID);
                rs = ps.executeQuery();
                while (rs.next()) {
                    check = true;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            closeConnection();
        }
        return check;
    }

    public List<UserDTO> getListUser(String search) throws SQLException {
        UserDTO user = new UserDTO();
        List<UserDTO> list = new ArrayList<>();
        try {
            conn = DB_Ultis.getConnection();
            if (conn != null) {
                String sql = "SELECT userID,fullName,phone,address,roleID,statusID,createDate "
                        + "FROM tblUser "
                        + "WHERE fullName LIKE ? AND statusID = 1";
                ps = conn.prepareStatement(sql);
                ps.setString(1, "%" + search + "%");
                rs = ps.executeQuery();
                while (rs.next()) {
                    String ID = rs.getString("userID");
                    String name = rs.getString("fullName");
                    String phone = rs.getString("phone");
                    String address = rs.getString("address");
                    String roleID = rs.getString("roleID");
                    boolean status = rs.getBoolean("statusID");
                    String date = rs.getString("createDate");
                    list.add(new UserDTO(ID, name, "*****", phone, address, roleID, status, date));
                }
            }
        } catch (Exception e) {
        } finally {
            closeConnection();
        }
        return list;
    }

    public boolean updateInfo(UserDTO user) throws SQLException {
        boolean check = false;
        try {
            conn = DB_Ultis.getConnection();
            if (conn != null) {
                String sql = "UPDATE tblUser "
                        + "SET fullName =?, phone =?,address =?,roleID =? "
                        + "WHERE userID =?";
                ps = conn.prepareStatement(sql);
                ps.setString(1, user.getFullName());
                ps.setString(2, user.getPhone());
                ps.setString(3, user.getAddress());
                ps.setString(4, user.getRoleID());
                ps.setString(5, user.getUserID());
                check = ps.executeUpdate() == 0 ? false : true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (ps != null) {
                ps.close();
            }
            if (conn != null) {
                conn.close();
            }
        }
        return check;
    }

    public boolean delete(String userID) throws SQLException {
        boolean check = false;
        try {
            conn = DB_Ultis.getConnection();
            if (conn != null) {
                String sql = "UPDATE tblUser SET statusID = 0 WHERE userID = ?";
                ps = conn.prepareStatement(sql);
                ps.setString(1, userID);
                check = ps.executeUpdate() > 0;
            }
        } catch (Exception e) {
        } finally {
            if (ps != null) {
                ps.close();
            }
            if (conn != null) {
                conn.close();
            }
        }
        return check;
    }
}
