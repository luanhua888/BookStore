/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import dto.CategoryDTO;
import dto.ProductDTO;
import java.awt.print.Book;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import ultis.DB_Ultis;

/**
 *
 * @author blueb
 */
public class ProductDAO {

    Connection conn = null;
    PreparedStatement ps = null;
    ResultSet rs = null;

    private void closeConnection() throws SQLException {
        if (rs != null) {
            rs.close();
        }
        if (ps != null) {
            ps.close();
        }
        if (conn != null) {
            conn.close();
        }
    }

    public List<ProductDTO> getListBookByName(String search) throws SQLException {
        List<ProductDTO> proList = new ArrayList<>();
        try {
            conn = DB_Ultis.getConnection();
            if (conn != null) {
                String sql = "SELECT productID,productName,description,categoryID,price,quantity,statusID,image "
                        + "FROM tblProduct "
                        + "WHERE productName LIKE ? AND statusID = 1";
                ps = conn.prepareStatement(sql);
                ps.setString(1, "%" + search + "%");
                rs = ps.executeQuery();
                while (rs.next()) {
                    String proID = rs.getString("productID");
                    String proName = rs.getString("productName");
                    String desc = rs.getString("description");
                    String cateID = rs.getString("categoryID");
                    float price = rs.getFloat("price");
                    int quantity = rs.getInt("quantity");
                    boolean status = rs.getBoolean("statusID");
                    String img = rs.getString("image");
                    proList.add(new ProductDTO(proID, proName, desc, cateID, price, quantity, status, img));
                }
            }
        } catch (Exception e) {
        } finally {
            closeConnection();
        }
        return proList;
    }

    public boolean updateID(ProductDTO product) throws SQLException {
        boolean check = false;

        try {
            conn = DB_Ultis.getConnection();
            if (conn != null) {
                String sql = "UPDATE tblProduct "
                        + "SET price=?, quantity=? "
                        + "WHERE productID=?";
                ps = conn.prepareStatement(sql);
                ps.setFloat(1, product.getPrice());
                ps.setInt(2, product.getQuantity());
                ps.setString(3, product.getProductID());
                check = ps.executeUpdate() == 0 ? false : true;
            }
        } catch (Exception e) {
        } finally {
            if (ps != null) {
                ps.close();
            }
            if (conn != null) {
                conn.close();
            }
        }
        return check;
    }

    public boolean InsertBook(ProductDTO product) throws SQLException {
        boolean result = false;
        try {
            conn = DB_Ultis.getConnection();
            if (conn != null) {
                String sql = "INSERT INTO tblProduct(productID,productName,description,categoryID,price,quantity,statusID,image) "
                        + "VALUES (?,?,?,?,?,?,?,?)";
                ps = conn.prepareStatement(sql);
                ps.setString(1, product.getProductID());
                ps.setString(2, product.getProductName());
                ps.setString(3, product.getDesc());
                ps.setString(4, product.getCateID());
                ps.setFloat(5, product.getPrice());
                ps.setInt(6, product.getQuantity());
                ps.setBoolean(7, product.isStatusID());
                ps.setString(8, product.getImge());
                result = ps.executeUpdate() == 0 ? false : true;
            }
        } catch (Exception e) {
        } finally {
            closeConnection();
        }
        return result;
    }

    public List<CategoryDTO> getListCategory() throws SQLException {
        ArrayList<CategoryDTO> list = new ArrayList<>();
        try {
            conn = DB_Ultis.getConnection();
            if (conn != null) {
                String sql = "SELECT categoryID,cateName FROM tblCate ORDER BY categoryID";
                ps = conn.prepareStatement(sql);
                rs = ps.executeQuery();
                while (rs.next()) {
                    String cateID = rs.getString("categoryID");
                    String cateName = rs.getString("cateName");
                    list.add(new CategoryDTO(cateID, cateName));
                }
            }
        } catch (Exception e) {
            System.out.println(e);
        } finally {
            closeConnection();
        }
        return list;
    }

    public boolean checkDup(String productID) throws SQLException {
        boolean check = false;
        try {
            conn = DB_Ultis.getConnection();
            if (conn != null) {
                String sql = "SELECT productID FROM tblProduct WHERE productID = ?";
                ps = conn.prepareStatement(sql);
                ps.setString(1, productID);
                rs = ps.executeQuery();
                while (rs.next()) {
                    check = true;
                }
            }
        } catch (Exception e) {

        } finally {
            closeConnection();
        }
        return check;
    }

    public String getCateID(String categoryID) throws SQLException {

        try {
            conn = DB_Ultis.getConnection();
            if (conn != null) {
                String sql = "SELECT categoryID FROM tblCate WHERE categoryID = ?";
                ps = conn.prepareStatement(sql);
                ps.setString(1, categoryID);
                rs = ps.executeQuery();
                if (rs.next()) {
                    String cate = rs.getString("categoryID");
                    return cate;
                }
            }
        } catch (Exception e) {
            System.out.println(e);
        } finally {
            closeConnection();
        }
        return "";
    }

    public boolean delete(String productID) throws SQLException {
        boolean check = false;

        try {
            conn = DB_Ultis.getConnection();
            if (conn != null) {
                String sql = "UPDATE tblProduct SET statusID = 0 WHERE productID = ?";
                ps = conn.prepareStatement(sql);
                ps.setString(1, productID);
                check = ps.executeUpdate() > 0;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (ps != null) {
                ps.close();
            }
            if (conn != null) {
                conn.close();
            }
        }
        return check;
    }

    public ProductDTO getListBookByID(String productID) throws SQLException {
        ProductDTO pro = new ProductDTO();
        try {
            conn = DB_Ultis.getConnection();
            if (conn != null) {
                String sql = "SELECT productID,productName,description,categoryID,price,quantity,statusID,image "
                        + "FROM tblProduct "
                        + "WHERE productID = ? AND statusID = 1";
                ps = conn.prepareStatement(sql);
                ps.setString(1, productID);
                rs = ps.executeQuery();
                while (rs.next()) {
                    String proID = rs.getString("productID");
                    String proName = rs.getString("productName");
                    String desc = rs.getString("description");
                    String cateID = rs.getString("categoryID");
                    float price = rs.getFloat("price");
                    int quantity = rs.getInt("quantity");
                    boolean status = rs.getBoolean("statusID");
                    String img = rs.getString("image");
                    pro = new ProductDTO(productID, proName, desc, cateID, price, quantity, status, img);
                }
            }
        } catch (Exception e) {
        } finally {
            closeConnection();
        }
        return pro;
    }

    public int getQuantityOfBook(String id) throws SQLException {
        int quan = 0;
        try {
            conn = DB_Ultis.getConnection();
            if (conn != null) {
                String sql = "SELECT quantity FROM tblProduct WHERE productID = ?";
                ps = conn.prepareStatement(sql);
                ps.setString(1, id);
                rs = ps.executeQuery();
                if(rs!=null){
                    quan = rs.getInt("quantity");
                }
            }
        } catch (Exception e) {
        } finally {
            closeConnection();
        }
        return quan;
    }

}
